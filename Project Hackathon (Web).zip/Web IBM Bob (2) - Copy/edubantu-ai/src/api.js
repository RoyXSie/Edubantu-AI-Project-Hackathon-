// Langflow API integration with mock fallback
import mockData from './mockData';

// Mengambil URL & API Key dari file .env (jika ada), atau fallback ke template default
const LANGFLOW_URL =
  process.env.REACT_APP_LANGFLOW_URL ||
  'http://localhost:7860/api/v1/run/YOUR_FLOW_ID?stream=false';

const LANGFLOW_API_KEY =
  process.env.REACT_APP_LANGFLOW_API_KEY ||
  '';

/**
 * Helper untuk membersihkan escaped characters (\n, \", \\) dari string LLM
 */
function unescapeText(text) {
  if (typeof text !== 'string') return '';
  return text
    .replace(/\\n/g, '\n')
    .replace(/\\"/g, '"')
    .replace(/\\\\/g, '\\')
    .trim();
}

/**
 * Parse LLM response — handles raw JSON, markdown code fences, or fallback.
 */
function parseResponse(raw) {
  if (!raw) return null;
  try {
    return JSON.parse(raw);
  } catch {
    const match = raw.match(/```(?:json)?\s*([\s\S]*?)```/);
    if (match) {
      try { return JSON.parse(match[1]); } catch { /* fall through */ }
    }
    const braceMatch = raw.match(/\{[\s\S]*\}/);
    if (braceMatch) {
      try { return JSON.parse(braceMatch[0]); } catch { /* fall through */ }
    }
  }
  return null;
}

/**
 * Main function: calls Langflow, falls back to mock on any error.
 */
export async function generateContent({ subject, topic, grade, level, jumlah_sesi, durasi_per_sesi }) {
  const sesiInfo   = jumlah_sesi     ? `, Jumlah Sesi: ${jumlah_sesi}`         : '';
  const durasiInfo = durasi_per_sesi ? `, Durasi Per Sesi: ${durasi_per_sesi}` : '';

  const formattedText =
    `Mata Pelajaran: ${subject}, Topik: ${topic}, Jenjang: ${grade}, Tingkat Pemahaman: ${level}${sesiInfo}${durasiInfo}`;

  const sessionId = `edubantu-${Date.now()}-${Math.random().toString(36).slice(2, 9)}`;

  const payload = {
    output_type: 'chat',
    input_type:  'chat',
    input_value: formattedText,
    session_id:  sessionId,
    tweaks: {
      "PromptTemplate-1": {
        "subject": subject,
        "topic": topic,
        "grade": grade,
        "learning_level": level
      },
      "PromptTemplate-2": {
        "subject": subject,
        "topic": topic,
        "grade": grade,
        "learning_level": level
      },
      "Prompt Template": {
        "subject": subject,
        "topic": topic,
        "grade": grade,
        "learning_level": level
      }
    }
  };

  const headers = {
    'Content-Type':                  'application/json',
    'Accept':                        'application/json',
    'X-Tunnel-Skip-Anti-Abuse-Page': 'true',
    'ngrok-skip-browser-warning':    'true'
  };

  if (LANGFLOW_API_KEY) {
    headers['x-api-key'] = LANGFLOW_API_KEY;
    headers['Authorization'] = `Bearer ${LANGFLOW_API_KEY}`;
  }

  try {
    const controller = new AbortController();
    const timeoutId  = setTimeout(() => controller.abort(), 120000); // 120s timeout

    console.log('🔗 [EduBantu Target API]:', LANGFLOW_URL);

    const response = await fetch(LANGFLOW_URL, {
      method:  'POST',
      headers: headers,
      body:    JSON.stringify(payload),
      signal:  controller.signal,
    });

    clearTimeout(timeoutId);

    if (!response.ok) {
      const errBody = await response.text().catch(() => '');
      throw new Error(`HTTP ${response.status}: ${errBody.slice(0, 200)}`);
    }

    const json = await response.json();

    const outputs = json?.outputs?.[0]?.outputs;
    const out     = outputs?.[outputs.length - 1] ?? outputs?.[0];
    const rawText =
      out?.results?.message?.text  ||
      out?.artifacts?.[0]?.data    ||
      out?.messages?.[0]?.message  ||
      out?.results?.text           ||
      json?.result                 ||
      (typeof json === 'string' ? json : null);

    const parsed = parseResponse(rawText);

    if (parsed) {
      const rawBankSoal = parsed.bank_soal || parsed.soal || [];
      const rawKunciJawaban = parsed.kunci_jawaban || [];

      const formatQuestionText = (text) => {
        if (!text) return '';
        const cleanText = unescapeText(text);
        return cleanText
          .replace(/\s+([A-D]\.\s)/g, '\n$1')
          .trim();
      };

      const normalizedSoal = rawBankSoal.map((item, index) => {
        const matchingAnswerObj = rawKunciJawaban.find((k) => k.id === item.id) || rawKunciJawaban[index];
        
        const rawQuestion = item.pertanyaan || item.soal || item.question || `Soal ${index + 1}`;
        const formattedQuestion = formatQuestionText(rawQuestion);

        let kunciStr = '';
        let pembahasanStr = '';

        if (typeof matchingAnswerObj === 'object' && matchingAnswerObj !== null) {
          kunciStr = unescapeText(matchingAnswerObj.jawaban || matchingAnswerObj.kunci || '');
          pembahasanStr = unescapeText(matchingAnswerObj.pembahasan || matchingAnswerObj.explanation || '');
        } else if (typeof matchingAnswerObj === 'string') {
          pembahasanStr = unescapeText(matchingAnswerObj);
        }

        const fullJawabanText = kunciStr 
          ? `**Kunci Jawaban:** ${kunciStr}\n\n**Pembahasan:**\n${pembahasanStr}`.trim()
          : pembahasanStr || 'Kunci jawaban tidak tersedia.';

        return {
          id: item.id || index + 1,
          difficulty: item.tingkat || item.difficulty || (index === 4 ? 'hots' : index >= 2 ? 'medium' : 'easy'),
          soal: formattedQuestion,
          question: formattedQuestion,
          jawaban: fullJawabanText,
          answer: fullJawabanText
        };
      });

      const normalizedData = {
        rpp: unescapeText(parsed.rpp_markdown || parsed.rpp || ''),
        materi: unescapeText(parsed.materi_markdown || parsed.materi || ''),
        soal: normalizedSoal
      };

      if (normalizedData.rpp && !normalizedData.rpp.includes("membutuhkan informasi lebih lanjut")) {
        return { data: normalizedData, isMock: false };
      }
    }

    throw new Error('LLM output format not matched');
  } catch (err) {
    console.warn('⚠️ Langflow API error, falling back to mock:', err.message);
    await new Promise((r) => setTimeout(r, 1000));
    return { data: mockData, isMock: true };
  }
}