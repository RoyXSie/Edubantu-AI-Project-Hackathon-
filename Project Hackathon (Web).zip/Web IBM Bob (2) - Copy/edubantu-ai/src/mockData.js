// Realistic mock data for demo mode
const mockData = {
  rpp: `# RPP RINGKAS — Teorema Pythagoras

## Identitas Mata Pelajaran
| | |
|---|---|
| **Mata Pelajaran** | Matematika |
| **Kelas / Semester** | Kelas 8 / Semester 1 |
| **Alokasi Waktu** | 2 × 40 menit (1 Pertemuan) |
| **Kompetensi Dasar** | Menjelaskan dan membuktikan teorema Pythagoras dan tripel Pythagoras |

---

## Tujuan Pembelajaran
Setelah proses pembelajaran, peserta didik mampu:
1. Menjelaskan konsep teorema Pythagoras pada segitiga siku-siku.
2. Menghitung panjang sisi yang tidak diketahui menggunakan teorema Pythagoras.
3. Mengidentifikasi tripel Pythagoras dan menerapkannya dalam masalah kontekstual.

---

## Kegiatan Pembelajaran

### 🟦 Pendahuluan (10 menit)
- Guru menyampaikan salam dan mengecek kehadiran peserta didik.
- Apersepsi: menampilkan gambar kota dengan bangunan bertingkat dan bertanya "Bagaimana tukang bangunan memastikan sudut dinding benar-benar 90°?"
- Menyampaikan tujuan dan cakupan materi pembelajaran.

### 🟩 Kegiatan Inti (60 menit)
**Eksplorasi:**
- Peserta didik diberikan penggaris, kertas millimeter, dan gunting untuk membangun persegi di tiap sisi segitiga siku-siku.
- Guru membimbing peserta didik menemukan pola: luas persegi terbesar = jumlah luas dua persegi lainnya.

**Diskusi & Elaborasi:**
- Peserta didik secara berpasangan menyelesaikan 3 soal kontekstual (tangga, lebar sungai, diagonal lapangan).
- Guru memfasilitasi konfirmasi jawaban dan meluruskan miskonsepsi.

**Penguatan:**
- Presentasi singkat 2 kelompok terpilih.

### 🟥 Penutup (10 menit)
- Refleksi: peserta didik menuliskan 1 hal yang dipahami dan 1 pertanyaan yang masih membingungkan.
- Guru memberikan PR: Buku Siswa halaman 47 no. 3, 5, dan 7.

---

## Penilaian
| Aspek | Teknik | Instrumen |
|---|---|---|
| Pengetahuan | Tes Tertulis | 5 Soal Pilihan Ganda + Uraian |
| Keterampilan | Observasi | Rubrik Diskusi Kelompok |
| Sikap | Jurnal Guru | Keaktifan & Kerjasama |

---

## Media & Sumber Belajar
- 📱 Aplikasi GeoGebra (simulasi segitiga interaktif)
- 📖 Buku Teks Matematika Kelas 8 Kurikulum Merdeka
- 🖼️ Lembar Kerja Peserta Didik (LKPD) Teorema Pythagoras
`,

  materi: `# Materi Ajar: Teorema Pythagoras

## 📌 Konsep Utama

### Apa itu Teorema Pythagoras?
Teorema Pythagoras menyatakan bahwa **pada segitiga siku-siku**, kuadrat panjang sisi miring (hipotenusa) sama dengan **jumlah kuadrat panjang kedua sisi siku-sikunya**.

> **Formula:** c² = a² + b²
> 
> Di mana **c** adalah hipotenusa (sisi terpanjang, selalu di depan sudut siku-siku), dan **a**, **b** adalah sisi-sisi siku-siku lainnya.

---

## 🔢 Cara Penggunaan

**Mencari hipotenusa (c):**
\`\`\`
c = √(a² + b²)
\`\`\`

**Mencari sisi siku-siku (a atau b):**
\`\`\`
a = √(c² - b²)
b = √(c² - a²)
\`\`\`

---

## 🌍 Contoh Kehidupan Nyata

### Contoh 1 — Tangga Gedung
Sebuah tangga sepanjang **5 meter** disandarkan ke tembok. Kaki tangga berjarak **3 meter** dari tembok. Berapa ketinggian yang dicapai tangga?

**Penyelesaian:**
- Hipotenusa (tangga) = 5 m
- Sisi horizontal = 3 m
- Sisi vertikal = √(5² − 3²) = √(25 − 9) = √16 = **4 meter** ✅

### Contoh 2 — Diagonal Lapangan Sepak Bola
Lapangan berukuran **60 m × 80 m**. Berapa panjang diagonal lapangan?

**Penyelesaian:**
- d = √(60² + 80²) = √(3600 + 6400) = √10000 = **100 meter** ✅

---

## 📐 Tripel Pythagoras
Tripel Pythagoras adalah tiga bilangan bulat positif (**a, b, c**) yang memenuhi **a² + b² = c²**.

| Tripel | Contoh |
|--------|--------|
| (3, 4, 5) | Dasar — paling sering digunakan |
| (5, 12, 13) | Sering muncul di soal HOTS |
| (8, 15, 17) | Jarang tapi penting |
| (7, 24, 25) | Untuk soal tingkat lanjut |

---

## ⚠️ Kesalahan Umum
1. ❌ Salah mengidentifikasi mana sisi hipotenusa → Selalu pastikan c adalah sisi **terpanjang**.
2. ❌ Lupa mengakarkan hasil akhir → Ingat, c² = hasil, jadi c = √hasil.
3. ❌ Mencampurkan satuan (cm vs m) → Konversi satuan terlebih dahulu.
`,

  soal: [
    {
      id: 1,
      difficulty: "easy",
      question: "Sebuah segitiga siku-siku memiliki dua sisi siku-siku berukuran 3 cm dan 4 cm. Hitunglah panjang sisi miringnya!",
      answer: `**Jawaban: 5 cm**

**Langkah Penyelesaian:**
1. Identifikasi: a = 3 cm, b = 4 cm, cari c (hipotenusa).
2. Gunakan teorema Pythagoras: c² = a² + b²
3. Substitusi: c² = 3² + 4² = 9 + 16 = 25
4. Hasil: c = √25 = **5 cm** ✅

*Ini adalah tripel Pythagoras (3, 4, 5) — hafalkan!*`,
    },
    {
      id: 2,
      difficulty: "easy",
      question: "Sebuah layar TV berbentuk persegi panjang berukuran 12 inci × 5 inci. Berapakah ukuran diagonal TV tersebut?",
      answer: `**Jawaban: 13 inci**

**Langkah Penyelesaian:**
1. Diagonal membagi persegi panjang menjadi dua segitiga siku-siku.
2. a = 12 inci, b = 5 inci, cari diagonal d.
3. d² = 12² + 5² = 144 + 25 = 169
4. d = √169 = **13 inci** ✅

*Ini adalah tripel Pythagoras (5, 12, 13)!*`,
    },
    {
      id: 3,
      difficulty: "medium",
      question: "Sebuah kapal berlayar sejauh 20 km ke arah Timur, kemudian berbelok ke arah Utara sejauh 15 km. Berapakah jarak lurus kapal tersebut dari titik awalnya?",
      answer: `**Jawaban: 25 km**

**Langkah Penyelesaian:**
1. Visualisasikan: perjalanan membentuk dua sisi segitiga siku-siku.
   - Sisi horizontal (Timur) = 20 km
   - Sisi vertikal (Utara) = 15 km
2. Cari hipotenusa (jarak lurus):
   - d² = 20² + 15² = 400 + 225 = 625
   - d = √625 = **25 km** ✅

*Perhatikan: Ini adalah tripel (15, 20, 25) — kelipatan dari (3, 4, 5).*`,
    },
    {
      id: 4,
      difficulty: "medium",
      question: "Sebuah tangga panjang 10 m disandarkan ke tembok. Ujung tangga mencapai ketinggian 8 m. Berapakah jarak kaki tangga dari tembok? Apakah (6, 8, 10) merupakan tripel Pythagoras?",
      answer: `**Jawaban: 6 meter; Ya, (6, 8, 10) adalah tripel Pythagoras**

**Langkah Penyelesaian:**
1. c = 10 m (tangga = hipotenusa), b = 8 m (ketinggian), cari a (jarak kaki dari tembok).
2. a² = c² − b² = 10² − 8² = 100 − 64 = 36
3. a = √36 = **6 m** ✅
4. Verifikasi tripel: 6² + 8² = 36 + 64 = 100 = 10² → **Ya, (6, 8, 10) adalah tripel Pythagoras** (kelipatan 2 dari (3,4,5)).`,
    },
    {
      id: 5,
      difficulty: "hots",
      question: "[HOTS] Seorang arsitek merancang taman berbentuk persegi panjang ABCD. Diagonal AC = 26 m dan sisi AD = 10 m. Jika biaya pemasangan pagar Rp150.000/meter, hitunglah total biaya pagar seluruh taman! Jelaskan langkah-langkah penyelesaianmu secara sistematis.",
      answer: `**Jawaban: Rp 8.400.000**

**Langkah Penyelesaian Sistematis:**

**Step 1 — Cari sisi AB:**
Diagonal AC = 26 m, sisi AD = 10 m. Segitiga ACD siku-siku di D.
- AB² = AC² − AD² = 26² − 10² = 676 − 100 = 576
- AB = √576 = **24 m**

**Step 2 — Hitung keliling taman:**
Keliling = 2 × (AD + AB) = 2 × (10 + 24) = 2 × 34 = **68 m**

**Step 3 — Hitung total biaya:**
Biaya = Keliling × Harga/meter = 68 × Rp150.000 = **Rp 10.200.000**

> *Catatan: Jika soal menanyakan hanya dua sisi (tanpa semua sisi), total bisa berbeda. Pastikan siswa membaca soal dengan teliti.*

**Kemampuan yang Diuji:**
- ✅ Multi-step reasoning
- ✅ Aplikasi teorema Pythagoras dalam konteks nyata
- ✅ Konversi dan kalkulasi keuangan`,
    },
  ],
};

export default mockData;
