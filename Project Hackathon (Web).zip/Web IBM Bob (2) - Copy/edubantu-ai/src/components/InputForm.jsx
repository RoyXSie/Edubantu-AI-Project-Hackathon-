import React from 'react';

const LEVEL_ICONS = {
  basic:    '🧩',
  standard: '📚',
  advanced: '🚀',
};

export default function InputForm({ form, onChange, onSubmit, loading, t }) {
  const { subject, topic, grade, level, jumlah_sesi, durasi_per_sesi } = form;

  const levels = [
    { value: 'basic',    label: t.levelBasic,    desc: t.levelBasicDesc    },
    { value: 'standard', label: t.levelStandard,  desc: t.levelStandardDesc },
    { value: 'advanced', label: t.levelAdvanced,  desc: t.levelAdvancedDesc },
  ];

  return (
    <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 sm:p-8">
      {/* Section header */}
      <div className="mb-6">
        <h2 className="text-xl font-bold text-gray-900">{t.formTitle}</h2>
        <p className="mt-1 text-sm text-gray-500">{t.formSubtitle}</p>
      </div>

      <div className="space-y-6">
        {/* Row 1: Subject + Grade */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
          {/* Subject */}
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-1.5">
              {t.labelSubject} <span className="text-red-500">*</span>
            </label>
            <input
              list="subject-list"
              value={subject}
              onChange={(e) => onChange('subject', e.target.value)}
              placeholder={t.placeholderSubject}
              className="w-full px-3.5 py-2.5 rounded-xl border border-gray-200 text-sm bg-gray-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all"
            />
            <datalist id="subject-list">
              {t.subjects.map((s) => <option key={s} value={s} />)}
            </datalist>
          </div>

          {/* Grade */}
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-1.5">
              {t.labelGrade} <span className="text-red-500">*</span>
            </label>
            <select
              value={grade}
              onChange={(e) => onChange('grade', e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-xl border border-gray-200 text-sm bg-gray-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all appearance-none"
            >
              <option value="">— Pilih Kelas —</option>
              {t.grades.map((g) => <option key={g} value={g}>{g}</option>)}
            </select>
          </div>
        </div>

        {/* Topic */}
        <div>
          <label className="block text-sm font-semibold text-gray-700 mb-1.5">
            {t.labelTopic} <span className="text-red-500">*</span>
          </label>
          <input
            type="text"
            value={topic}
            onChange={(e) => onChange('topic', e.target.value)}
            placeholder={t.placeholderTopic}
            className="w-full px-3.5 py-2.5 rounded-xl border border-gray-200 text-sm bg-gray-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all"
          />
        </div>

        {/* Row 3: Jumlah Sesi + Durasi Per Sesi */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
          {/* Jumlah Sesi */}
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-1.5">
              {t.labelSesi}
            </label>
            <input
              type="number"
              min="1"
              max="32"
              value={jumlah_sesi}
              onChange={(e) => onChange('jumlah_sesi', e.target.value)}
              placeholder={t.placeholderSesi}
              className="w-full px-3.5 py-2.5 rounded-xl border border-gray-200 text-sm bg-gray-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all"
            />
          </div>

          {/* Durasi Per Sesi */}
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-1.5">
              {t.labelDurasi}
            </label>
            <input
              type="text"
              value={durasi_per_sesi}
              onChange={(e) => onChange('durasi_per_sesi', e.target.value)}
              placeholder={t.placeholderDurasi}
              className="w-full px-3.5 py-2.5 rounded-xl border border-gray-200 text-sm bg-gray-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all"
            />
          </div>
        </div>

        {/* Learning Level */}
        <div>
          <label className="block text-sm font-semibold text-gray-700 mb-3">
            {t.labelLevel} <span className="text-red-500">*</span>
          </label>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            {levels.map(({ value, label, desc }) => (
              <label
                key={value}
                className={`relative flex flex-col gap-0.5 cursor-pointer rounded-xl border-2 p-4 transition-all duration-150 hover:border-indigo-300 ${
                  level === value
                    ? 'border-indigo-500 bg-indigo-50'
                    : 'border-gray-200 bg-gray-50'
                }`}
              >
                <input
                  type="radio"
                  name="level"
                  value={value}
                  checked={level === value}
                  onChange={() => onChange('level', value)}
                  className="sr-only"
                />
                {level === value && (
                  <div className="absolute top-2 right-2 w-4 h-4 rounded-full bg-indigo-600 flex items-center justify-center">
                    <svg className="w-2.5 h-2.5 text-white" fill="currentColor" viewBox="0 0 12 12">
                      <path d="M10.28 2.28L4 8.56 1.72 6.28a1 1 0 00-1.44 1.44l3 3a1 1 0 001.44 0l7-7a1 1 0 00-1.44-1.44z"/>
                    </svg>
                  </div>
                )}
                <span className="text-xl">{LEVEL_ICONS[value]}</span>
                <span className={`text-sm font-semibold mt-1 ${level === value ? 'text-indigo-700' : 'text-gray-800'}`}>
                  {label}
                </span>
                <span className="text-xs text-gray-500">{desc}</span>
              </label>
            ))}
          </div>
        </div>

        {/* Submit Button */}
        <button
          onClick={onSubmit}
          disabled={loading || !subject || !topic || !grade || !level}
          className={`w-full py-3.5 px-6 rounded-xl font-semibold text-sm text-white transition-all duration-200 flex items-center justify-center gap-2.5
            ${loading || !subject || !topic || !grade || !level
              ? 'bg-gray-300 cursor-not-allowed'
              : 'bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-700 hover:to-violet-700 btn-glow active:scale-[0.98]'
            }`}
        >
          {loading ? (
            <>
              <svg className="w-5 h-5 animate-spin" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
              </svg>
              <span>{t.loadingMsg}</span>
            </>
          ) : (
            <>
              <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M9.813 15.904L9 18.75l-.813-2.846a4.5 4.5 0 00-3.09-3.09L2.25 12l2.846-.813a4.5 4.5 0 003.09-3.09L9 5.25l.813 2.846a4.5 4.5 0 003.09 3.09L15.75 12l-2.846.813a4.5 4.5 0 00-3.09 3.09z" />
              </svg>
              <span>{t.btnGenerate}</span>
            </>
          )}
        </button>
      </div>
    </div>
  );
}
