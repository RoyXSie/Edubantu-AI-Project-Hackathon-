import React, { useState } from 'react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import remarkMath from 'remark-math';
import rehypeKatex from 'rehype-katex';
import html2pdf from 'html2pdf.js';

// Difficulty badge config
const DIFFICULTY = {
  easy:   { label: null, bg: 'bg-emerald-100 text-emerald-800', dot: 'bg-emerald-500' },
  medium: { label: null, bg: 'bg-amber-100   text-amber-800',   dot: 'bg-amber-500'   },
  hots:   { label: null, bg: 'bg-red-100     text-red-800',     dot: 'bg-red-500'     },
};

function getDiffConfig(difficulty, t) {
  const map = {
    easy:   { ...DIFFICULTY.easy,   label: t?.badgeEasy   },
    medium: { ...DIFFICULTY.medium, label: t?.badgeMedium },
    hots:   { ...DIFFICULTY.hots,   label: t?.badgeHots   },
  };
  return map[difficulty] || map.medium;
}

function sanitizeMarkdown(text) {
  if (!text) return '';
  return text
    .replace(/<br\s*\/?>/gi, '\n')
    .replace(/(\|.*?\|)\s*(\|.*?\|)/g, '$1\n$2')
    // Membersihkan double backslash dari JSON LLM tanpa merusak simbol LaTeX KaTeX
    .replace(/\\\\/g, '\\')
    .trim();
}

// Custom Markdown components with smart page break support
const markdownComponents = {
  table: ({ children }) => (
    <div className="my-2 border border-gray-200 rounded-xl overflow-hidden">
      <table className="w-full text-xs border-collapse table-fixed">
        {children}
      </table>
    </div>
  ),
  thead: ({ children }) => (
    <thead className="bg-slate-100 text-gray-800 font-semibold pdf-avoid-break">{children}</thead>
  ),
  tbody: ({ children }) => (
    <tbody className="divide-y divide-gray-200 bg-white">{children}</tbody>
  ),
  tr: ({ children }) => (
    <tr className="hover:bg-slate-50/50 transition-colors pdf-avoid-break" style={{ pageBreakInside: 'avoid', breakInside: 'avoid' }}>
      {children}
    </tr>
  ),
  th: ({ children }) => (
    <th className="px-2 py-1.5 text-left font-semibold border-r border-gray-200 last:border-r-0 align-top break-words text-[11px] bg-indigo-50/50 text-indigo-900">
      {children}
    </th>
  ),
  td: ({ children }) => (
    <td className="px-2 py-1.5 border-r border-gray-200 last:border-r-0 align-top leading-snug break-words text-[11px]">
      {children}
    </td>
  ),
  // Lepas pdf-avoid-break dari p dan li agar paragraf/poin daftar mengalir lancar mengisi sisa halaman
  p: ({ children }) => (
    <p className="mb-1.5 leading-relaxed">
      {children}
    </p>
  ),
  li: ({ children }) => (
    <li className="mb-0.5">
      {children}
    </li>
  ),
  // Pastikan H2 dan H3 terlindung agar tidak terpisah dari paragraf pertama di bawahnya
  h2: ({ children }) => (
    <h2 className="text-base font-bold text-gray-900 mt-4 mb-2 pdf-avoid-break" style={{ pageBreakInside: 'avoid', breakInside: 'avoid' }}>
      {children}
    </h2>
  ),
  h3: ({ children }) => (
    <h3 className="text-sm font-semibold text-gray-800 mt-3 mb-1.5 pdf-avoid-break" style={{ pageBreakInside: 'avoid', breakInside: 'avoid' }}>
      {children}
    </h3>
  ),
};

function QuestionCard({ q, index, t, isExporting }) {
  const [open, setOpen] = useState(false);
  const diff = getDiffConfig(q.difficulty, t);
  const showAnswer = open || isExporting;

  return (
    <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden mb-2.5 pdf-avoid-break" style={{ pageBreakInside: 'avoid', breakInside: 'avoid' }}>
      <div className="p-4">
        <div className="flex items-start justify-between gap-3">
          <div className="flex items-start gap-3 flex-1 min-w-0">
            <div className={`w-7 h-7 rounded-full ${diff.dot} flex-shrink-0 flex items-center justify-center text-white text-xs font-bold mt-0.5`}>
              {index}
            </div>
            <div className="flex-1">
              <div className="flex items-center gap-2 flex-wrap mb-1.5">
                <span className={`badge ${diff.bg}`}>
                  <span className={`w-1.5 h-1.5 rounded-full ${diff.dot} mr-1.5`} />
                  {diff.label}
                </span>
                <span className="text-xs text-gray-400">{t?.questionLabel} {index}</span>
              </div>
              <div className="text-sm text-gray-800 leading-relaxed whitespace-pre-line">
                <ReactMarkdown 
                  remarkPlugins={[remarkGfm, remarkMath]} 
                  rehypePlugins={[rehypeKatex]} 
                  components={markdownComponents}
                >
                  {sanitizeMarkdown(q.question || q.soal)}
                </ReactMarkdown>
              </div>
            </div>
          </div>
        </div>
      </div>

      {!isExporting && (
        <div className="border-t border-gray-100">
          <button
            onClick={() => setOpen((v) => !v)}
            className="w-full flex items-center justify-between px-4 py-2 text-sm font-medium text-indigo-600 hover:bg-indigo-50 transition-colors"
          >
            <span className="flex items-center gap-2">
              <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                <path strokeLinecap="round" strokeLinejoin="round" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
              </svg>
              {open ? t?.hideAnswer : t?.showAnswer}
            </span>
          </button>
        </div>
      )}

      {showAnswer && (
        <div className="px-4 pb-4 pt-2.5 bg-slate-50 border-t border-gray-100">
          <div className="text-[11px] font-semibold text-gray-500 uppercase tracking-wider mb-1.5">
            {t?.answerLabel || 'Kunci Jawaban & Pembahasan'}
          </div>
          <div className="prose prose-sm max-w-none text-gray-700 whitespace-pre-line leading-relaxed">
            <ReactMarkdown 
              remarkPlugins={[remarkGfm, remarkMath]} 
              rehypePlugins={[rehypeKatex]} 
              components={markdownComponents}
            >
              {sanitizeMarkdown(q.answer || q.jawaban)}
            </ReactMarkdown>
          </div>
        </div>
      )}
    </div>
  );
}

function Tab({ active, onClick, children }) {
  return (
    <button
      onClick={onClick}
      className={`px-4 py-3 text-sm font-medium whitespace-nowrap transition-colors duration-150 ${
        active ? 'tab-active border-b-2 border-indigo-600 text-indigo-600 font-semibold' : 'tab-inactive text-gray-500 hover:text-gray-700'
      }`}
    >
      {children}
    </button>
  );
}

function MetaBadge({ label, value, color }) {
  const colors = {
    indigo:  'bg-indigo-100  text-indigo-800',
    violet:  'bg-violet-100  text-violet-800',
    sky:     'bg-sky-100     text-sky-800',
    emerald: 'bg-emerald-100 text-emerald-800',
  };
  return (
    <div className="flex flex-col gap-0.5">
      <span className="text-xs text-gray-400 font-medium">{label}</span>
      <span className={`badge ${colors[color] || colors.indigo} py-1 px-3 text-sm`}>{value}</span>
    </div>
  );
}

const LEVEL_LABELS = {
  basic:    { id: 'Perlu Bimbingan', en: 'Needs Guidance' },
  standard: { id: 'Standar',         en: 'Standard'       },
  advanced: { id: 'Mahir',           en: 'Advanced'       },
};

export default function OutputDashboard({ result, form, isMock, t, lang, onCopyAll, copied }) {
  const [activeTab, setActiveTab] = useState('rpp');
  const [isExporting, setIsExporting] = useState(false);

  const levelLabel = LEVEL_LABELS[form?.level]?.[lang || 'id'] || form?.level;

  const handleFullPDFExport = async () => {
    const element = document.getElementById('output-content-area');
    if (!element) return;

    setIsExporting(true);

    const subjectStr = (form?.subject || 'BahanAjar').replace(/\s+/g, '_');
    const topicStr   = (form?.topic   || 'EduBantuAI').replace(/\s+/g, '_');

    const opt = {
      margin:       [8, 10, 8, 10],
      filename:     `EduBantu_AI_${subjectStr}_${topicStr}.pdf`,
      image:        { type: 'jpeg', quality: 0.98 },
      html2canvas:  { scale: 2, useCORS: true, logging: false, scrollY: 0, scrollX: 0 },
      jsPDF:        { unit: 'mm', format: 'a4', orientation: 'portrait' },
      // PENTING: Menghapus avoid-all serta p, li, h2, h3 dari larangan potong otomatis
      pagebreak:    { mode: ['css', 'legacy'], avoid: ['.pdf-avoid-break', 'tr'] },
    };

    try {
      await new Promise((resolve) => setTimeout(resolve, 400));
      await html2pdf().set(opt).from(element).save();
    } catch (err) {
      console.error('Export PDF error:', err);
    } finally {
      setIsExporting(false);
    }
  };

  if (!result) {
    return (
      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-10 flex flex-col items-center justify-center text-center gap-4">
        <div className="w-16 h-16 rounded-2xl bg-indigo-50 flex items-center justify-center">
          <svg className="w-8 h-8 text-indigo-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M19.5 14.25v-2.625a3.375 3.375 0 00-3.375-3.375h-1.5A1.125 1.125 0 0113.5 7.125v-1.5a3.375 3.375 0 00-3.375-3.375H8.25m0 12.75h7.5m-7.5 3H12M10.5 2.25H5.625c-.621 0-1.125.504-1.125 1.125v17.25c0 .621.504 1.125 1.125 1.125h12.75c.621 0 1.125-.504 1.125-1.125V11.25a9 9 0 00-9-9z" />
          </svg>
        </div>
        <p className="text-gray-400 text-sm">{t?.emptyState}</p>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden" id="output-dashboard">
      {/* Header */}
      <div className="px-6 pt-6 pb-4 border-b border-gray-100">
        {isMock && (
          <div className="mb-4 flex items-center gap-2 text-xs text-amber-700 bg-amber-50 border border-amber-200 rounded-lg px-3 py-2">
            <svg className="w-4 h-4 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M12 9v3.75m-9.303 3.376c-.866 1.5.217 3.374 1.948 3.374h14.71c1.73 0 2.813-1.874 1.948-3.374L13.949 3.378c-.866-1.5-3.032-1.5-3.898 0L2.697 16.126zM12 15.75h.007v.008H12v-.008z" />
            </svg>
            {t?.mockMode}
          </div>
        )}

        <div className="flex flex-wrap gap-4 mb-5">
          <MetaBadge label={t?.metaSubject} value={form?.subject} color="indigo" />
          <MetaBadge label={t?.metaTopic}   value={form?.topic}   color="violet" />
          <MetaBadge label={t?.metaGrade}   value={form?.grade}   color="sky"    />
          <MetaBadge label={t?.metaLevel}   value={levelLabel}     color="emerald"/>
        </div>

        <div className="flex flex-wrap gap-2">
          <button
            onClick={handleFullPDFExport}
            disabled={isExporting}
            className="flex items-center gap-2 px-4 py-2 rounded-xl bg-gray-900 text-white text-sm font-medium hover:bg-gray-700 transition-colors shadow-sm disabled:opacity-50"
          >
            <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M3 16.5v2.25A2.25 2.25 0 005.25 21h13.5A2.25 2.25 0 0021 18.75V16.5M16.5 12L12 16.5m0 0L7.5 12m4.5 4.5V3" />
            </svg>
            {isExporting ? 'Memproses PDF...' : t?.exportPDF}
          </button>
          <button
            onClick={onCopyAll}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-medium border transition-all ${
              copied
                ? 'bg-emerald-50 border-emerald-300 text-emerald-700'
                : 'bg-white border-gray-200 text-gray-700 hover:bg-gray-50 hover:border-gray-300'
            }`}
          >
            {copied ? (
              <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M4.5 12.75l6 6 9-13.5" />
              </svg>
            ) : (
              <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M15.666 3.888A2.25 2.25 0 0013.5 2.25h-3c-1.03 0-1.9.693-2.166 1.638m7.332 0c.055.194.084.4.084.612v0a.75.75 0 01-.75.75H9a.75.75 0 01-.75-.75v0c0-.212.03-.418.084-.612m7.332 0c.646.049 1.288.11 1.927.184 1.1.128 1.907 1.077 1.907 2.185V19.5a2.25 2.25 0 01-2.25 2.25H6.75A2.25 2.25 0 014.5 19.5V6.257c0-1.108.806-2.057 1.907-2.185a48.208 48.208 0 011.927-.184" />
              </svg>
            )}
            {copied ? t?.copied : t?.copyAll}
          </button>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex border-b border-gray-100 overflow-x-auto">
        <Tab active={activeTab === 'rpp'}    onClick={() => setActiveTab('rpp')}>
          📋 {t?.tabRPP}
        </Tab>
        <Tab active={activeTab === 'materi'} onClick={() => setActiveTab('materi')}>
          📖 {t?.tabMateri}
        </Tab>
        <Tab active={activeTab === 'soal'}   onClick={() => setActiveTab('soal')}>
          ❓ {t?.tabSoal}
        </Tab>
      </div>

      {/* Interactive UI Content Area */}
      <div className="p-6 bg-white" id="output-content-area">
        {isExporting ? (
          <div className="space-y-6">
            <div>
              <h2 className="text-lg font-bold text-indigo-600 mb-3 border-b-2 border-indigo-500 pb-1.5 pdf-avoid-break">
                📋 {t?.tabRPP || 'MODUL AJAR (RPP)'}
              </h2>
              <div className="prose prose-indigo max-w-none text-gray-800 leading-relaxed">
                <ReactMarkdown 
                  remarkPlugins={[remarkGfm, remarkMath]} 
                  rehypePlugins={[rehypeKatex]} 
                  components={markdownComponents}
                >
                  {sanitizeMarkdown(result.rpp)}
                </ReactMarkdown>
              </div>
            </div>

            <div className="pt-2">
              <h2 className="text-lg font-bold text-indigo-600 mb-3 border-b-2 border-indigo-500 pb-1.5 pdf-avoid-break">
                📖 {t?.tabMateri || 'RINGKASAN MATERI AJAR'}
              </h2>
              <div className="prose prose-indigo max-w-none text-gray-800 leading-relaxed">
                <ReactMarkdown 
                  remarkPlugins={[remarkGfm, remarkMath]} 
                  rehypePlugins={[rehypeKatex]} 
                  components={markdownComponents}
                >
                  {sanitizeMarkdown(result.materi)}
                </ReactMarkdown>
              </div>
            </div>

            <div className="pt-2">
              <h2 className="text-lg font-bold text-indigo-600 mb-3 border-b-2 border-indigo-500 pb-1.5 pdf-avoid-break">
                ❓ {t?.tabSoal || 'BANK SOAL & PEMBAHASAN'}
              </h2>
              <div className="space-y-3">
                {(result.soal || []).map((q, i) => (
                  <QuestionCard key={q.id || i} q={q} index={i + 1} t={t} isExporting={isExporting} />
                ))}
              </div>
            </div>
          </div>
        ) : (
          <>
            {activeTab === 'rpp' && (
              <div className="prose prose-indigo max-w-none text-gray-800 leading-relaxed">
                <ReactMarkdown 
                  remarkPlugins={[remarkGfm, remarkMath]} 
                  rehypePlugins={[rehypeKatex]} 
                  components={markdownComponents}
                >
                  {sanitizeMarkdown(result.rpp)}
                </ReactMarkdown>
              </div>
            )}

            {activeTab === 'materi' && (
              <div className="prose prose-indigo max-w-none text-gray-800 leading-relaxed">
                <ReactMarkdown 
                  remarkPlugins={[remarkGfm, remarkMath]} 
                  rehypePlugins={[rehypeKatex]} 
                  components={markdownComponents}
                >
                  {sanitizeMarkdown(result.materi)}
                </ReactMarkdown>
              </div>
            )}

            {activeTab === 'soal' && (
              <div className="space-y-4">
                {(result.soal || []).map((q, i) => (
                  <QuestionCard key={q.id || i} q={q} index={i + 1} t={t} isExporting={isExporting} />
                ))}
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}