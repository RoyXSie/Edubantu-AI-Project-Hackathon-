import React, { useState, useRef, useCallback } from 'react';
import './App.css';
import Navbar from './components/Navbar';
import InputForm from './components/InputForm';
import OutputDashboard from './components/OutputDashboard';
import { generateContent } from './api';
import translations from './i18n';

const DEFAULT_FORM = {
  subject: '',
  topic: '',
  grade: '',
  level: 'standard',
  jumlah_sesi: '',
  durasi_per_sesi: '',
};

export default function App() {
  const [lang, setLang]       = useState('id');
  const [form, setForm]       = useState(DEFAULT_FORM);
  const [loading, setLoading] = useState(false);
  const [result, setResult]   = useState(null);
  const [isMock, setIsMock]   = useState(false);
  const [copied, setCopied]   = useState(false);

  const outputRef = useRef(null);
  const t = translations[lang];

  // Form field change
  const handleChange = useCallback((field, value) => {
    setForm((prev) => ({ ...prev, [field]: value }));
  }, []);

  // Toggle language
  const handleToggleLang = useCallback(() => {
    setLang((l) => (l === 'id' ? 'en' : 'id'));
  }, []);

  // Generate content
  const handleGenerate = useCallback(async () => {
    if (!form.subject || !form.topic || !form.grade || !form.level) return;
    setLoading(true);
    setResult(null);
    try {
      const { data, isMock: mock } = await generateContent({
        subject: form.subject,
        topic: form.topic,
        grade: form.grade,
        level: form.level,
        jumlah_sesi: form.jumlah_sesi,
        durasi_per_sesi: form.durasi_per_sesi,
      });
      setResult(data);
      setIsMock(mock);
      // Scroll to output after a tick
      setTimeout(() => {
        outputRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }, 100);
    } finally {
      setLoading(false);
    }
  }, [form]);

  // Export to PDF using html2pdf.js (lazy-loaded)
  const handleExportPDF = useCallback(async () => {
    const el = document.getElementById('output-dashboard');
    if (!el) return;
    try {
      // Dynamic import — only loaded when needed
      const html2pdf = (await import('html2pdf.js')).default;
      const levelMap = { basic: 'Perlu Bimbingan', standard: 'Standar', advanced: 'Mahir' };
      html2pdf()
        .set({
          margin:       [10, 10, 10, 10],
          filename:     `EduBantu_${form.topic || 'output'}.pdf`,
          image:        { type: 'jpeg', quality: 0.95 },
          html2canvas:  { scale: 2, useCORS: true },
          jsPDF:        { unit: 'mm', format: 'a4', orientation: 'portrait' },
          pagebreak:    { mode: ['avoid-all', 'css', 'legacy'] },
        })
        .from(el)
        .save();
    } catch (err) {
      console.error('PDF export failed:', err);
      window.print();
    }
  }, [form.topic]);

  // Copy all text to clipboard
  const handleCopyAll = useCallback(async () => {
    if (!result) return;
    const text = [
      `=== ${t.tabRPP} ===\n${result.rpp}`,
      `\n=== ${t.tabMateri} ===\n${result.materi}`,
      `\n=== ${t.tabSoal} ===\n` +
        (result.soal || [])
          .map((q, i) => `[${i + 1}] ${q.question}\n${t.answerLabel}:\n${q.answer}`)
          .join('\n\n'),
    ].join('\n');

    try {
      await navigator.clipboard.writeText(text);
    } catch {
      // Fallback for older browsers
      const ta = document.createElement('textarea');
      ta.value = text;
      ta.style.position = 'fixed';
      ta.style.opacity = '0';
      document.body.appendChild(ta);
      ta.select();
      document.execCommand('copy');
      document.body.removeChild(ta);
    }
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  }, [result, t]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-indigo-50/30 to-violet-50/20">
      <Navbar lang={lang} onToggleLang={handleToggleLang} t={t} />

      <main className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-10">
        {/* Hero strip */}
        <div className="mb-8 text-center">
          <div className="inline-flex items-center gap-2 bg-indigo-50 border border-indigo-200 text-indigo-700 text-xs font-semibold px-4 py-1.5 rounded-full mb-4">
            <span className="w-1.5 h-1.5 rounded-full bg-indigo-500 animate-pulse" />
            Powered by IBM Watsonx &amp; Langflow AI
          </div>
          <h1 className="text-3xl sm:text-4xl font-extrabold text-gray-900 tracking-tight">
            {lang === 'id'
              ? <>Buat Bahan Ajar <span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-600 to-violet-600">Adaptif</span> dalam Detik</>
              : <>Generate <span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-600 to-violet-600">Adaptive</span> Teaching Materials in Seconds</>
            }
          </h1>
          <p className="mt-3 text-gray-500 text-sm sm:text-base max-w-xl mx-auto">
            {lang === 'id'
              ? 'RPP Kurikulum Merdeka, Draf Materi Ajar, dan 5 Soal Adaptif (Mudah → HOTS) — langsung dari AI.'
              : 'Merdeka Curriculum Lesson Plans, Teaching Materials, and 5 Adaptive Questions (Easy → HOTS) — straight from AI.'
            }
          </p>
        </div>

        {/* Two-column layout on large screens */}
        <div className="grid grid-cols-1 lg:grid-cols-5 gap-6 items-start">
          {/* Input form — left 2/5 */}
          <div className="lg:col-span-2">
            <InputForm
              form={form}
              onChange={handleChange}
              onSubmit={handleGenerate}
              loading={loading}
              t={t}
            />
          </div>

          {/* Output — right 3/5 */}
          <div className="lg:col-span-3" ref={outputRef}>
            {loading ? (
              <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-10 flex flex-col items-center justify-center gap-5 text-center min-h-[260px]">
                <div className="relative">
                  <div className="w-16 h-16 rounded-full border-4 border-indigo-100 border-t-indigo-600 animate-spin" />
                  <div className="absolute inset-0 flex items-center justify-center">
                    <svg className="w-6 h-6 text-indigo-600" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                      <path strokeLinecap="round" strokeLinejoin="round" d="M9.813 15.904L9 18.75l-.813-2.846a4.5 4.5 0 00-3.09-3.09L2.25 12l2.846-.813a4.5 4.5 0 003.09-3.09L9 5.25l.813 2.846a4.5 4.5 0 003.09 3.09L15.75 12l-2.846.813a4.5 4.5 0 00-3.09 3.09z" />
                    </svg>
                  </div>
                </div>
                <div>
                  <p className="font-semibold text-gray-800">{lang === 'id' ? 'Memproses...' : 'Processing...'}</p>
                  <p className="text-sm text-gray-500 mt-1 max-w-xs">{t.loadingMsg}</p>
                </div>
                <div className="flex gap-1.5">
                  {[0, 1, 2].map((i) => (
                    <div
                      key={i}
                      className="w-2 h-2 rounded-full bg-indigo-400 animate-bounce"
                      style={{ animationDelay: `${i * 0.15}s` }}
                    />
                  ))}
                </div>
              </div>
            ) : (
              <OutputDashboard
                result={result}
                form={form}
                isMock={isMock}
                t={t}
                lang={lang}
                onExportPDF={handleExportPDF}
                onCopyAll={handleCopyAll}
                copied={copied}
              />
            )}
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="mt-16 border-t border-gray-200 bg-white no-print">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-6 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-gray-400">
          <div className="flex items-center gap-2">
            <div className="w-5 h-5 rounded-md bg-gradient-to-br from-indigo-600 to-violet-600 flex items-center justify-center">
              <svg className="w-3 h-3 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M12 6.042A8.967 8.967 0 006 3.75c-1.052 0-2.062.18-3 .512v14.25A8.987 8.987 0 016 18c2.305 0 4.408.867 6 2.292m0-14.25a8.966 8.966 0 016-2.292c1.052 0 2.062.18 3 .512v14.25A8.987 8.987 0 0018 18a8.966 8.966 0 00-6 2.292m0-14.25v14.25" />
              </svg>
            </div>
            <span className="font-semibold text-gray-600">EduBantu AI</span>
          </div>
          <span>
            {lang === 'id'
              ? 'Asisten Guru & Generator Kurikulum Adaptif — IBM Hackathon 2026'
              : 'Teacher Assistant & Adaptive Curriculum Generator — IBM Hackathon 2026'
            }
          </span>
          <span>© 2026 EduBantu AI. All rights reserved.</span>
        </div>
      </footer>
    </div>
  );
}
