# EduBantu AI — Asisten Guru & Generator Kurikulum Adaptif

> AI-powered Lesson Plan (RPP) & Adaptive Assessment Generator for Indonesian teachers — built with React, Tailwind CSS, and Langflow.

---

## 🚀 Quick Start

```bash
# 1. Install dependencies
npm install

# 2. Configure API (optional — demo mode works without it)
cp .env.example .env
# Edit .env and set REACT_APP_LANGFLOW_URL to your Langflow flow endpoint

# 3. Run development server
npm start
# → Opens at http://localhost:3000

# 4. Build for production
npm run build
```

---

## ✨ Features

| Feature | Details |
|---|---|
| **RPP Ringkas** | Auto-generated 1-page Lesson Plan (Kurikulum Merdeka format) |
| **Materi Ajar** | Core concepts + real-world examples in structured Markdown |
| **Bank Soal Adaptif** | 5 questions: 2 Easy 🟢 / 2 Medium 🟡 / 1 HOTS 🔴 with step-by-step solutions |
| **Adaptive Levels** | Perlu Bimbingan / Standar / Mahir — AI tailors content per level |
| **Bilingual UI** | Toggle between Bahasa Indonesia & English |
| **Demo Mode** | Realistic mock data if Langflow is unavailable — always demo-ready |
| **Export PDF** | One-click PDF export via html2pdf.js |
| **Copy All Text** | Copy entire output to clipboard |

---

## 🔌 Langflow Integration

The app posts to a Langflow flow with the following JSON payload:

```json
{
  "input_value": "<constructed teacher prompt>",
  "output_type": "chat",
  "input_type": "chat",
  "tweaks": {}
}
```

Expected JSON response schema from your flow:

```json
{
  "rpp": "# RPP markdown string...",
  "materi": "# Materi Ajar markdown...",
  "soal": [
    { "id": 1, "difficulty": "easy",   "question": "...", "answer": "..." },
    { "id": 2, "difficulty": "easy",   "question": "...", "answer": "..." },
    { "id": 3, "difficulty": "medium", "question": "...", "answer": "..." },
    { "id": 4, "difficulty": "medium", "question": "...", "answer": "..." },
    { "id": 5, "difficulty": "hots",   "question": "...", "answer": "..." }
  ]
}
```

---

## 🗂 Project Structure

```
src/
├── components/
│   ├── Navbar.jsx          # Top nav with language toggle
│   ├── InputForm.jsx       # Teacher input form
│   └── OutputDashboard.jsx # 3-tab output panel
├── api.js                  # Langflow integration + mock fallback
├── i18n.js                 # Bilingual translations (id / en)
├── mockData.js             # Realistic demo data (Teorema Pythagoras)
├── App.js                  # Root component
├── App.css                 # Prose & global overrides
└── index.css               # Tailwind directives + global styles
```

---

## 📦 Tech Stack

- **React 18** — UI framework
- **Tailwind CSS 3** — Utility-first styling
- **@tailwindcss/typography** — Markdown prose styling
- **react-markdown** — Markdown renderer
- **html2pdf.js** — PDF export
- **Langflow** — AI flow orchestration (IBM Watsonx backend)

---

## 🏆 IBM Hackathon 2025

Built for the IBM Hackathon, demonstrating how AI (IBM Watsonx + Langflow) can help Indonesian teachers generate high-quality, adaptive teaching materials in seconds.
